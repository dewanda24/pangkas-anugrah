"use client";

import { useEffect, useState } from "react";
import { supabase } from "@/lib/supabase";
import { useRouter } from "next/navigation";

type Pelanggan = {
  id: number;
  tanggal: string;
  jam: string;
  jenis: string;
  harga: number;
  keterangan: string | null;
  created_at: string;
};

export default function PelangganPage() {
  const [pelanggan, setPelanggan] = useState<Pelanggan[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const router = useRouter();

  useEffect(() => {
    fetchPelanggan();
  }, []);

  async function fetchPelanggan() {
    setLoading(true);
    setError(null);

    const { data, error } = await supabase
      .from("pelanggan")
      .select("*")
      .order("id", { ascending: false });

    if (error) {
      setError(error.message);
      setPelanggan([]);
    } else if (data) {
      setPelanggan(data);
    }

    setLoading(false);
  }

  return (
    <div className="p-6 max-w-6xl mx-auto">
      <h1 className="text-3xl font-bold mb-6">Data Pelanggan</h1>

      <button
        onClick={() => router.push("/pelanggan/tambah")}
        className="mb-6 bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700"
      >
        Tambah Pelanggan
      </button>

      {loading && <p>Loading data pelanggan...</p>}

      {error && (
        <p className="mb-4 text-red-600 font-semibold">Error: {error}</p>
      )}

      {!loading && !error && pelanggan.length === 0 && (
        <p>Belum ada data pelanggan.</p>
      )}

      {!loading && !error && pelanggan.length > 0 && (
        <table className="w-full border border-gray-300 rounded">
          <thead>
            <tr className="bg-gray-100">
              <th className="border p-2">ID</th>
              <th className="border p-2">Tanggal</th>
              <th className="border p-2">Jam</th>
              <th className="border p-2">Jenis</th>
              <th className="border p-2">Harga</th>
              <th className="border p-2">Keterangan</th>
              <th className="border p-2">Aksi</th>
            </tr>
          </thead>
          <tbody>
            {pelanggan.map((p) => (
              <tr key={p.id}>
                <td className="border p-2 text-center">{p.id}</td>
                <td className="border p-2">{p.tanggal}</td>
                <td className="border p-2">{p.jam}</td>
                <td className="border p-2">{p.jenis}</td>
                <td className="border p-2">
                  Rp{p.harga.toLocaleString("id-ID")}
                </td>
                <td className="border p-2">{p.keterangan ?? "-"}</td>
                <td className="border p-2 flex justify-center gap-2">
                  <button
                    onClick={() => router.push(`/pelanggan/edit/${p.id}`)}
                    className="bg-yellow-400 px-2 rounded hover:bg-yellow-500"
                  >
                    Edit
                  </button>
                  <button
                    onClick={async () => {
                      if (confirm("Yakin ingin hapus data pelanggan ini?")) {
                        const { error } = await supabase
                          .from("pelanggan")
                          .delete()
                          .eq("id", p.id);
                        if (error) {
                          alert("Gagal hapus: " + error.message);
                        } else {
                          fetchPelanggan();
                        }
                      }
                    }}
                    className="bg-red-600 px-2 rounded text-white hover:bg-red-700"
                  >
                    Hapus
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
}
