// src/app/layout.tsx
import "../styles/globals.css";
import { ReactNode } from "react";
import Link from "next/link";

export const metadata = {
  title: "Pangkas Anugrah V2",
  description: "Aplikasi manajemen pelanggan pangkas",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="id">
      <body className="bg-gray-50 min-h-screen">
        <header className="bg-blue-700 text-white p-4 shadow-md">
          <nav className="max-w-6xl mx-auto flex justify-between items-center">
            <Link href="/" className="text-xl font-bold">
              Pangkas Anugrah V2
            </Link>
            <div className="space-x-4">
              <Link href="/pelanggan" className="hover:underline">
                Pelanggan
              </Link>
              <Link href="/login" className="hover:underline">
                Login
              </Link>
            </div>
          </nav>
        </header>

        <main className="max-w-6xl mx-auto p-6">{children}</main>

        <footer className="text-center p-4 text-gray-500">
          &copy; {new Date().getFullYear()} Pangkas Anugrah
        </footer>
      </body>
    </html>
  );
}
