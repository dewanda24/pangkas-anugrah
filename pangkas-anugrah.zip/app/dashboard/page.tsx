import { supabase } from "@/lib/supabase";
import LogoutButton from "@/components/logoutButton";

export default async function DashboardPage() {
  // Ambil data pelanggan dari Supabase (server-side)
  const { data: pelanggan, error } = await supabase
    .from("pelanggan")
    .select("*")
    .order("tanggal", { ascending: false });

  if (error) {
    return <div>Error: {error.message}</div>;
  }

  const total = pelanggan?.reduce((acc, p) => acc + (p.harga || 0), 0) || 0;

  return (
    <div className="p-6">
      <h1 className="text-2xl font-semibold mb-4">Dashboard</h1>
      <div className="mb-4">Total pelanggan: {pelanggan?.length || 0}</div>
      <div className="mb-4">
        Total pendapatan: Rp{total.toLocaleString("id-ID")}
      </div>
      <LogoutButton />
    </div>
  );
}
