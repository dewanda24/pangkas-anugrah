// app/auth/layout.tsx
import "../../styles/globals.css";

export default function AuthLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body className="bg-gray-100 flex items-center justify-center min-h-screen">
        <main className="w-full max-w-md p-6 bg-white rounded-lg shadow-md">
          {children}
        </main>
      </body>
    </html>
  );
}
